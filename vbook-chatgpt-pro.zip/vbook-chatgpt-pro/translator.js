async function translate(text, config, memory, cache) {

    if (cache[text]) {
        return cache[text];
    }

    let termList = "";
    for (const key in memory.terms) {
        termList += key + " = " + memory.terms[key] + "\n";
    }

    const prompt = `
Bạn là dịch giả truyện tiên hiệp chuyên nghiệp.

QUY TẮC:
- Dịch Trung sang Việt cổ phong nhẹ
- Giữ nguyên nội dung
- Không dùng markdown
- Không giữ chữ Trung
- Giữ tên riêng theo bảng thuật ngữ
- Văn phong truyện mượt

BẢNG THUẬT NGỮ:
${termList}

NỘI DUNG:
${text}
`;

    const response = await fetch(config.apiUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + config.apiKey
        },
        body: JSON.stringify({
            model: config.model,
            messages: [
                { role: "user", content: prompt }
            ],
            temperature: config.temperature
        })
    });

    const data = await response.json();

    let result = data.choices[0].message.content;

    cache[text] = result;

    return result;
}